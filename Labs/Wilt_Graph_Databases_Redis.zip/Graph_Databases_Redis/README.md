I did not collaborate with anyone during the project
Everything was written by me
It took about 4-5 hours
It was pretty enjoyable to do.
No other concerns.
