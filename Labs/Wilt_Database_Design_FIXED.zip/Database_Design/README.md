
I did not collaborate with anyone else on this lab.
The query method was writen by Dr. Mongan, while everything else was written by me
It took about 2 hours to complete.
I did enjoy the assignment, it was very interesting to get all the quirks out of the 
program.
No concerns but a question, why is res before every query. I tried looking it up
online but I could not find anything about it.