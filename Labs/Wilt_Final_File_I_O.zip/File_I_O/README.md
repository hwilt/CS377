CS 377: Database Design \
File I/O Lab \
By: Henry Wilt

In this lab, we had to create a class to represent a data model of some type, I choose one with three characteristics. Name, age, and 5k time to have data that models with my xc team. In this classes it has to return a dict structure. \
We also have to create another class which writes a dict structure to a comma-separated value file. The first line being the headers of the dict and then the rest being the data. It will also appened to the file and not overwrite what there before.\
In the main function, I had to instantiate three or more dict objects and then write them to a file that is specified with a parameter. 