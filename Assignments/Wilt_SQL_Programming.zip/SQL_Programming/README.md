I did not collaborate with anyone on this project.
I used portions from the old Database_Programming Assignment from October.
It took me about 4-5 hours, but with a lot of breaks for social media.
I did enjoy grinding through the making of the methods, it's now gotten to where I can do it with my eyes closed.
No other concerns.