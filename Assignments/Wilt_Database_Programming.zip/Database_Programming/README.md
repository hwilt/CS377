I did not collaborate with anyone on this project
Didn't use anyone' code
It took about 4 hours to complete over 2 days,
I did enjoy this assignemnet, it was fun to make the class and do the commenting 
for each method
No concerns