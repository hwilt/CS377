I did not collaborate with anyone on this assignment
Everything was done and written by me
It took me about 30 minutes to complete this assignment
It was ok
No conerns about this assignment
