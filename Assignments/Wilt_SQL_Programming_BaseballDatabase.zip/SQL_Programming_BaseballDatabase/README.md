I did not collaborate with anyone on this project
Everything was written by me except for the query method
It took me about 2 hours to complete the assignment
It was fine, I did not enjoy searching through all the data and trying to get it to work
No concerns.